from django.apps import AppConfig


class CollegeAutoConfig(AppConfig):
    name = 'college_auto'
