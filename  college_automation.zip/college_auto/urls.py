from django.urls import path
from . import views
app_name = 'college_auto'
urlpatterns = [
	path('',views.index,name='index'),	
	path('gallery', views.gallery, name='gallery'),
	path('contact', views.contact, name='contact'),
	path('user_login', views.user_login, name='user_login'),
	path('register', views.register, name='register'),
	path('update', views.update, name='update'),
	path('user_logout',views.user_logout, name='user_logout'),
	path('admin_login', views.user_login, name='admin_login'),

]
