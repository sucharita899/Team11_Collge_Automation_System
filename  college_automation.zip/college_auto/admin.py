from django.contrib import admin
from college_auto.models import UserProfileInfo
from college_auto.models import StudentProfileInfo
# Register your models here.
#admin.site.unregister(UserProfileInfo)
admin.site.register(UserProfileInfo)
admin.site.register(StudentProfileInfo)
