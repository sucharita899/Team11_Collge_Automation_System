from django.shortcuts import render,redirect, reverse

# Create your views here.

from college_auto.forms import UserForm, StudentForm 
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from college_auto.models import UserProfileInfo
from college_auto.models import StudentProfileInfo


def index(request):
	return render(request, 'index.html')
def gallery(request):
	return render(request, 'gallery.html')
def contact(request):
	return render(request, 'contact.html')


@login_required
def special(request):
    return HttpResponse("You are logged in !")
@login_required
def user_logout(request):
    logout(request)
    return render(request,'user_logout.html')
def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
        if user_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()
            registered = True 
            return render(request, 'index.html')
        else:
            print(user_form.errors)
	   # return render(request,redirect('register'), {'user_form':user_form,'registered':registered})
	    #return reverse(views.register)
    else:
        user_form = UserForm()
        return render(request,'register.html',{'user_form':user_form,'registered':registered})
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)

        if user:
            if user.is_active:
                login(request,user)
                
                return HttpResponseRedirect("update")
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'user_login.html')
def update(request):
    updated = False
    if request.method == 'POST':
        student_form = StudentForm(data=request.POST)
        print(student_form)
        if student_form.is_valid():
            user = student_form.save()
            print("hello")
            #user.set_attendance(student.attendance)
            #user.set_marks(student.marks)
            user.save()
            updated= True
            #return HttpResponseRedirect("index")
            return render(request, 'index.html')
        else:
            print(student_form.errors)
    else:
        student_form = StudentForm()
        return render(request,'update.html',{'student_form':student_form,'updated':updated})
def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username,password=password)
        a=UserProfileInfo.objects.filter(username=username).exists()
        b=UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
            return HttpResponseRedirect(reverse('index'))
        else:
            return Httpresponse('Invalid login details')
    else:
         return render(request,'admin_login.html') 
