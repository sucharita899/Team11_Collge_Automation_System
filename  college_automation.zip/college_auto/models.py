#/models.py
from django.db import models
from django.contrib.auth.models import User
#from college_auto.models import UserProfileInfo
#from college_auto.models import StudentProfileInfo

# Create your models here.

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=30, default='')
	password = models.CharField(max_length=10, default='')
	email    = models.CharField(max_length=30, default='@gmail.com')
#def __str__(self):
#return self.UserProfileInfo.username, self.UserProfileInfo.password

class StudentProfileInfo(models.Model):
	name = models.CharField(max_length=30, default='')
	regd = models.CharField(max_length=10, default='')
	attendance = models.FloatField(max_length=3, default='')
	marks = models.FloatField(max_length=3, default='')
#def __str__(self):
#	return self.StudentProfileInfo.name, self.StudentProfileInfo.regd, self.StudentProfileInfo.attendance, self.StudentProfileInfo.marks
